


print("*********多继承使用类名.__ini__ 发生的状态***********")

class Parent(object):
	def __init__(self, name):
		print("Parent的init 开始调用")
		self.name = name
		print("Parent的init 调用结束")

class Son1(Parent):
	def __init__(self, name, age):
		print("Son1 init 开始调用")
		self.age = age
		Parent.__init__(self, name)
		print("Son1 init 开始调用")

class Son2(Parent):
	def __init__(self, name, gender):
		print("Son2的 init 开始被调用")
		self.gender = gender
		Parent.__init__(self,name)
		print("Son2的init调用结束")

class Grandson(Son1, Son2):
	def __init__(self, name, age, gender):
		print("Grandson的 init 开始 调用")
		Son1.__init__(self, name, age) # 单独调用父类的初始化方法
		Son2.__init__(self, name, age) 
		print("*"*50)
		# super().__init__(name,age,gender)
		print("Grandson的 init 结束 调用")

gs = Grandson("grandson",12,'男')
print("姓名：",gs.name)
print("年龄：",gs.age)
print("性别：",gs.gender)





