import threading
import time
import socket



def send_msg(udp_socket):
	while True:
		# obtain data from keyboard
		msg = input("\nPlease input you want send data:")
		#
		dest_ip ="172.22.40.189"
		dest_port = int("7890")
		udp_socket.sendto(msg.encode("utf-8"),(dest_ip,dest_port))

		

def recv_msg(udp_socket):
	"""receive data"""
	while True:
		# 1. receive data
		recv_data = udp_socket.recvfrom(1024)
		receive_ip = recv_data[1]
		recv_data = recv_data[0].decode("utf-8")
		print(">>>:%s:%s"%(receive_ip,recv_data))
		


def main():
	# 1. create a udp socket
	udp_socket = socket.socket(socket.AF_INET,socket.SOCK_DGRAM)
	# bind
	# ip=""
	udp_socket.bind(("",7788))
	# create a subthread to receive data
	t = threading.Thread(target=recv_msg,args=(udp_socket,))
	t.start()
	# send data
	send_msg(udp_socket)

	

if __name__ == '__main__':
	main()