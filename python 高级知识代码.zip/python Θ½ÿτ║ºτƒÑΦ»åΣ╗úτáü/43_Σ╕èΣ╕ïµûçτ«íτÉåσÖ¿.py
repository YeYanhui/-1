
class File():
	def __init__(self, filname, mode):
		self.filname = filname
		self.mode = mode

	def __enter__(self):
		print("entering")
		self.f = open(self.filname, self.mode)

		return self.f

	def __exit__(self, *args):
		print("will exit")
		self.f.close()



with File('out.txt','w') as f:
	print("writing")
	f.write("hello python")