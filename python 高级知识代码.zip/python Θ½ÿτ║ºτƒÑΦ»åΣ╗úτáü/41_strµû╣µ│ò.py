class Foo:
	def __str__(self):
		return "Json"


obj = Foo()
print(obj)