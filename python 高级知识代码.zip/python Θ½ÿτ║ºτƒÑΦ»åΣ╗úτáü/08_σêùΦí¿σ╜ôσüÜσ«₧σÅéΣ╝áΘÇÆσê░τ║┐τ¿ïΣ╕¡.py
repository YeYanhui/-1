import threading 
import time



def work1(g_num):
	g_num.append(44)
	print("-----in work1, g_num is---",g_num)

def work2(g_num):
	# g_num.append
	print("-----in work2, g_num is---",g_num)

g_num = [11,22,33]

t1 = threading.Thread(target = work1, args = (g_num,) )
t1.start()

# 延迟一会，保证t1 线程中的事情做完

time.sleep(1)
t2 = threading.Thread(target = work2 , args = (g_num,))
t2.start()