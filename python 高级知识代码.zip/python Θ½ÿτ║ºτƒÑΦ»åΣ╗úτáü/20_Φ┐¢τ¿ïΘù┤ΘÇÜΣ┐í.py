from multiprocessing import Manager,Pool
import os,time,random


def reader(q):
	print("reader启动(%s),父进程为(%s)"%(os.getpid(),os.getpid()))
	for i in range(q.qsize()):
		print("reader从Queue获取到消息：%s"%q.get(True))

def writer(q):
	print("reader启动(%s),父进程为(%s)"%(os.getpid(),os.getpid()))
	for i in "itcast":
		q.put(i)





if __name__ == '__main__':
	print("(%s) start"%os.getpid())
	q = Manager().Queue()
	po = Pool()
	po.apply_async(writer, (q,))# 写数据
	time.sleep(1)
	po.apply_async(reader,(q,)) # 读数据
	po.close() 
	po.join()
	print("(%s) End" % os.getpid())