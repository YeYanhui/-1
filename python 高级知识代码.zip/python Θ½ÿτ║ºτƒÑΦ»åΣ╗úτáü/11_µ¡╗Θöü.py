import threading
import time

class MyThread1(threading.Thread):
	def run(self):
		# 对mutexA上锁
		mutexA.acquire()
		print(self.name+'-----do1----up-----')
		time.sleep(1)
		# 此时会堵塞，因为这个mutexB已经被其他线程抢先上锁
		mutexB.acquire()
		print(self.name+"-----do1----down-----")
		mutexB.release()
		mutexA.release()


class MyThread2(threading.Thread):
	def run(self):
		# 对mutexA上锁
		mutexB.acquire()
		print(self.name+'-----do2----up-----')
		time.sleep(1)
		mutexA.acquire()
		print(self.name+"-----do2----down-----")
		mutexA.release()
		mutexB.release()

if __name__ == "__main__":
	mutexA = threading.Lock()
	mutexB = threading.Lock()
	t1 = MyThread1()
	t2 = MyThread2()
	t1.start()
	t2.start()