
from multiprocessing import Process
import time

def run_proc():
	"""sub processs"""
	while True:
		print("-----2----")
		time.sleep(1)
		pass

if __name__ == "__main__":
	p = Process(target=run_proc)
	p.start()
	# main process
	while True:
		print("-----1-----")
		time.sleep(1)
