import threading
import time

# 创建一个类然后继承其方法
class Mythread(threading.Thread):
	def run(self):
		for i in range(3):
			time.sleep(1)
			msg = "I'm" + self.name + '@' + str(i)
			# name 中的属性是保存当前属性的名字
			print(msg)


if __name__ == "__main__":
	t1 = Mythread()
	t2 = Mythread()
	t1.start()
	t2.start()
