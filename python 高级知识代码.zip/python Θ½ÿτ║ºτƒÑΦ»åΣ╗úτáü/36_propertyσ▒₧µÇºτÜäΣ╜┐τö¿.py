class Foo(object):
	def get_bar(self):
		print("getter...")
		return 'laowang'

	def set_bar(self, value):
		print("setter...")
		return 'set value' + value

	def del_bar(self):
		print("deleter...")
		return 'laowang'

	BAR = property(get_bar, set_bar, del_bar, "description...")

obj = Foo()
obj.BAR = "Alex"
desc = Foo.BAR.__doc__
print(desc)
del obj.BAR
