class Foo:
	def func(self):
		print("func")
		return "func"

	# define property
	@property
	def prop(self):
		print("Prop")
		return "Prop"

foo_obj = Foo()
foo_obj.func()
foo_obj.prop
	