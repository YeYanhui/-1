
from multiprocessing import Process
import time,os

def run_proc():
	"""sub processs"""
	print("子进程运行中，pid=%d...."%os.getpid())
	print("子进程结束。。。。。")

		

if __name__ == "__main__":
	print("父进程pid:%d....."%os.getpid()) 
	p = Process(target=run_proc)
	p.start()

