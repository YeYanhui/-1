
class Foo(object):
	def __getitem__(self, key):
		print("__getitem__",key)

	def __delitem__(self, key):
		print("__delitem__", key)
	def __setitem__(self,key,value):
		print("__setitem__",key,value)


obj = Foo()
result = obj["Alan"]
obj["name"] = "Ye"

print(obj.__getitem__)
del obj["Alan"]
