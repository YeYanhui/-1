class Goods(object):
	def __init__(self):
		self.original_price = 100
		self.discount = 0.8

	@property
	def price(self):
		# 实际价格 = 原价 * 折扣
		new_price = self.original_price * self.discount
		print("1"*20)
		return new_price

	@price.setter
	def price(self, value):

		self.original_price = value
		print("2"*20)

	@price.deleter
	def price(self):
		print("3"*20)
		del self.original_price


obj = Goods()
obj.price
obj.price = 200
del obj.price
	