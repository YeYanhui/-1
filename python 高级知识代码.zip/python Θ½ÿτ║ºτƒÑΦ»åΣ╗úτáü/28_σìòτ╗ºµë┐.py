print("*********单继承super().__init__发生的状态*****")

class Parent(object):
	def __init__(self, name):
		self.name = name
		print('parent 的 init 结束被调用')

class Son1(Parent):
	"""docstring for Son1"""
	def __init__(self, name, age):
		self.age = age
		super().__init__(name)
		print("Son1 结束被调用")
class Grandson(Son1):
	def __init__(self, name, age, gender):
		super().__init__(name, age)
		print("Grandson 结束被调用")
	
	
gs = Grandson('grandson', 12, "男")
print("姓名：",gs.name)
print("age",gs.age)