

class MyList(object):
	def __init__(self):
		self.container = []
	def add(self, item):
		self.container.append(item)

mylist = MyList()
mylist.add(1)
mylist.add(2)
mylist.add(3)

