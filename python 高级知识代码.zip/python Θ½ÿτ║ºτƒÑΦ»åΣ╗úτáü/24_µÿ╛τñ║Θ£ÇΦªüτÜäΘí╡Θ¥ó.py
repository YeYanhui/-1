import socket,re

def handle_client(client_socket):
	# 为一个客户端服务
	recv_data = client_socket.recv(1024).decode('utf-8', errors = "ignore" )
	print("1==>",recv_data)
	request_header_lines = recv_data.splitlines()
	print("2==>",request_header_lines)
	for line in request_header_lines:
		print("3==>",line)


	http_request_line = request_header_lines[0]
	get_file_name = re.match("[^/]+(/[^ ]*)", http_request_line).group(1)
	print("file name is ===>%s" % get_file_name) 

	if get_file_name =="/":
		get_file_name = DOCUMENTS_ROOT + "/index.html"
	else :
		get_file_name = DOCUMENTS_ROOT + get_file_name

	print("file name is ===2>%s"%get_file_name)

	try:
		f = open(get_file_name,"rb")
	except IOError:
		response_headers = "HTTP/1.1 404 not found\r\n"
		response_headers += "\r\n"
		response_body = "=====sorry, file not found======"
	else:
		response_headers = "HTTP/1.1 200 OK\r\n"
		response_headers += "\r\n"
		response_body = f.read()
		f.close()

	finally:
		# 因为头信息在组织的时候，是按照字符串组织的，不能与以二进制打开文件读取的数据合并，因此分开发送
		# 先发送response的头信息
		client_socket.send(response_headers.encode('utf-8'))
		client_socket.send(response_body)
		client_socket.close()




def main():
	server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
	server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
	server_socket.bind(("",7789))
	server_socket.listen(128)
	while True:
		client_socket, client_addr = server_socket.accept()
		handle_client(client_socket)


DOCUMENTS_ROOT ="./http"

if __name__ == '__main__':
	main()