
class Foo(object):
	def __init__(self, name):
		self.name = name

	def ord_func(self):
		print("实例方法")

	@classmethod #类方法
	def class_func(cls):
		print('类方法')

	@staticmethod
	def static_func():
		print('静态方法')

f = Foo("中国")
# 调用实例方法
f.ord_func()
# 调用类方法
Foo.class_func()
# 调用静态方法
Foo.static_func()