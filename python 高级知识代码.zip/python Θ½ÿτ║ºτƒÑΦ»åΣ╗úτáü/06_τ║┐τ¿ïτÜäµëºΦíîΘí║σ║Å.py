import threading
import time

class Mythread(threading.Thread):
	def run(self):
		for i in range(3):
			time.sleep(1)
			msg = "I'm" + self.name + '@' + str(i)
			# name 中的属性是保存当前属性的名字
			print(msg)

def test():
	for i in range(5):
		t = Mythread()
		t.start()

if __name__ == "__main__":
	test()