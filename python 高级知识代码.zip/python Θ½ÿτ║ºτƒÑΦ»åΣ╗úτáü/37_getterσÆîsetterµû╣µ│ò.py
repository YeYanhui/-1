class Money(object):
	def __init__(self):
		self.money = 0

	def getMoney(self):
		return self.__money

	def setMoney(self, value):
		if isinstance(self, int):
			self.__money = value
		else:
			print("error:不是整型数字")

	money = property(getMoney, setMoney)

a = Money()
a.money = 100
print(a.money)