
class Foo:
	"""描述信息，这是用于查看类的描述信息"""
	def func(self):
		self.name = "Json"
		
		print("Hell world")

print(Foo.__doc__)

