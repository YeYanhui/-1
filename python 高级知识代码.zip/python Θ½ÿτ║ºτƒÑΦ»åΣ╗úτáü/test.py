class Person(object):
	def __init__(self):
		self.name = "Json"