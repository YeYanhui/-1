from multiprocessing import Process
import os
import time



def work1(nums):
	print("in Process1 pid:%d,nums:%s"%(os.getpid(),nums))
	for i in range(5):
		nums.append(i)
		time.sleep(1)
		print("in Process1 pid:%d,nums:%s"%(os.getpid(),nums))
		
def work2(nums):
	print("in Process2 pid:%d,nums:%s"%(os.getpid(),nums))

		

def main():
	nums = [11,22]
	p1 = Process(target=work1,args=(nums,))
	p1.start()
	p1.join()

	p2 = Process(target=work2,args=(nums,))
	p2.start()

if __name__ == '__main__':
	main()