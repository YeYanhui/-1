class Province(object):
	# 类属性
	country = "中国"
	def __init__(self, name):
		# 实例属性
		self.name = name

obj = Province("山东省")
print(obj.name)
print(Province.country)