from test import Person

obj = Person()
print(obj.__module__) #输出test（这个Person 在哪个模块）
print(obj.__class__) # 输出类